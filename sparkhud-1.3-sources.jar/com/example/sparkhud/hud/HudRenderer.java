package com.example.sparkhud.hud;

import com.example.sparkhud.SparkHUDMod;
import com.example.sparkhud.client.GammaNightVisionManager;
import com.example.sparkhud.config.ConfigManager;
import com.example.sparkhud.config.SparkHUDConfig;
import com.example.sparkhud.utils.GradientUtils;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HudRenderer {
    public static void render(GuiGraphicsExtractor graphics, DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        LocalPlayer player = client.player;
        if (player == null || client.level == null) return;
        ClientLevel world = client.level;
        SparkHUDConfig config = SparkHUDMod.CONFIG;
        int sw = client.getWindow().getGuiScaledWidth();
        int sh = client.getWindow().getGuiScaledHeight();

        // Масштабирование при смене разрешения
        if (config.savedScreenWidth > 0 && (config.savedScreenWidth != sw || config.savedScreenHeight != sh)) {
            float dx = (float) sw / config.savedScreenWidth;
            float dy = (float) sh / config.savedScreenHeight;
            if (config.leftCorner == SparkHUDConfig.Corner.CUSTOM) {
                config.leftX = (int)(config.leftX * dx);
                config.leftY = (int)(config.leftY * dy);
            }
            if (config.rightCorner == SparkHUDConfig.Corner.CUSTOM) {
                config.rightX = (int)(config.rightX * dx);
                config.rightY = (int)(config.rightY * dy);
            }
            for (SparkHUDConfig.CustomPanel p : config.customPanels) {
                p.x = (int)(p.x * dx);
                p.y = (int)(p.y * dy);
            }
            config.savedScreenWidth = sw;
            config.savedScreenHeight = sh;
            ConfigManager.save(config);
        }

        int worldHeight = renderWorld(graphics, client, player, world, config, sw, sh);
        renderEquipment(graphics, client, player, config, sw, sh, worldHeight);
        for (SparkHUDConfig.CustomPanel p : config.customPanels) renderCustom(graphics, client, p);
        renderNotifications(graphics, client, sw, sh);
    }

    /** Уведомления над хотбаром: «Гамма X%» и «Эликсир Кошка Y%». */
        private static void renderNotifications(GuiGraphicsExtractor graphics, Minecraft client, int sw, int sh) {
        boolean showG = GammaNightVisionManager.showGammaNotification();
        boolean showN = GammaNightVisionManager.showNvNotification();
        if (!showG && !showN) return;

        int lines = (showG ? 1 : 0) + (showN ? 1 : 0);
        int baseY = sh - 55 - (lines - 1) * 12;
        int idx = 0;

        if (showG) {
            float a = GammaNightVisionManager.getGammaAlpha();
            int alpha = ((int)(a * 255) & 0xFF) << 24;
            int color = alpha | 0x00FFFF55;
            int raw = GammaNightVisionManager.getGammaPercent();
            int snapped = (raw / 25) * 25; // гамма шаг 25%
            String text = "Гамма " + snapped + "%";
            int w = client.font.width(text);
            graphics.text(client.font, text, (sw - w) / 2, baseY + idx * 12, color, true);
            idx++;
        }
        if (showN) {
            float a = GammaNightVisionManager.getNvAlpha();
            int alpha = ((int)(a * 255) & 0xFF) << 24;
            int color = alpha | 0x00FFAAFF;
            int raw = GammaNightVisionManager.getNvPercent();
            int snapped = Math.round(raw); // NV шаг 1% — обновляется каждый тик
            String text = "Эликсир Кошка " + snapped + "%";
            int w = client.font.width(text);
            graphics.text(client.font, text, (sw - w) / 2, baseY + idx * 12, color, true);
        }
    }
    
    /** Левая панель: координаты, биом, погода, время. */
    private static int renderWorld(GuiGraphicsExtractor graphics, Minecraft client, LocalPlayer player, ClientLevel world, SparkHUDConfig config, int sw, int sh) {
        List<Object[]> lines = new ArrayList<>();
        if (config.showXyz) {
            lines.add(new Object[]{null, new String[]{
                    config.labelXyz + ": ",
                    String.format("%.1f", player.getX()),
                    String.format("%.1f", player.getY()),
                    String.format("%.1f", player.getZ())
            }});
        }
        if (config.showBiome) {
            Holder<Biome> b = world.getBiome(player.blockPosition());
            String key = b.unwrap().map(
                    k -> k.identifier().toLanguageKey("biome"),
                    bio -> "biome.minecraft.plains"
            );
            lines.add(new Object[]{config.labelBiome + ": " + Component.translatable(key).getString(), null});
        }
        if (config.showWeather) {
            String w = world.isThundering() ? "Гроза" : world.isRaining() ? "Дождь" : "Ясно";
            lines.add(new Object[]{config.labelWeather + ": " + w, null});
        }
        if (config.showGameTime) {
            long t = world.getGameTime() % 24000;
            lines.add(new Object[]{String.format("%s: %02d:%02d", config.labelGameTime,
                    (int)((t/1000+6)%24), (int)((t%1000)*60/1000)), null});
        }
        if (config.showRealTime) {
            LocalDateTime now = LocalDateTime.now();
            String d = config.dateFormat == SparkHUDConfig.DateFormat.DAY_MONTH
                    ? now.format(DateTimeFormatter.ofPattern("dd.MM"))
                    : now.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            String t = config.timeFormat == SparkHUDConfig.TimeFormat.HMS
                    ? now.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
                    : now.format(DateTimeFormatter.ofPattern("HH:mm"));
            lines.add(new Object[]{config.labelRealTime + ": " + d + " " + t, null});
        }
        if (lines.isEmpty()) return 0;

        int p = 4, lh = config.leftLineSpacing;
        int w = 0;
        for (Object[] line : lines) {
            int lw;
            if (line[0] != null) lw = client.font.width((String)line[0]);
            else {
                String[] a = (String[])line[1];
                lw = client.font.width(a[0]) + client.font.width(a[1]) + client.font.width(" / ")
                        + client.font.width(a[2]) + client.font.width(" / ") + client.font.width(a[3]);
            }
            w = Math.max(w, lw);
        }
        w += p * 2;
        int h = lines.size() * lh + p * 2;

        int[] pos = getCornerPos(config.leftCorner, config.leftX, config.leftY, w, h, sw, sh);
        int x = Math.max(0, Math.min(pos[0], sw - w));
        int y = Math.max(0, Math.min(pos[1], sh - h));

        if (config.showBackground) {
            int alpha = (int)((100 - config.backgroundTransparency) / 100.0 * 255);
            graphics.fill(x, y, x + w, y + h, (config.backgroundColor & 0xFFFFFF) | (alpha << 24));
        }
        int cy = y + p;
        for (Object[] line : lines) {
            if (line[0] != null) {
                String s = (String)line[0];
                if (config.leftGradient)
                    GradientUtils.drawGradientText(graphics, client.font, s, x + p, cy, config.leftStartColor, config.leftEndColor);
                else
                    graphics.text(client.font, s, x + p, cy, config.leftStartColor, true);
            } else {
                String[] parts = (String[])line[1];
                int cx = x + p;
                graphics.text(client.font, parts[0], cx, cy, config.leftStartColor, true);
                cx += client.font.width(parts[0]);
                int xC = config.xyzColors ? 0xFFFF5555 : config.leftStartColor;
                int yC = config.xyzColors ? 0xFF55FF55 : config.leftStartColor;
                int zC = config.xyzColors ? 0xFF5555FF : config.leftStartColor;
                graphics.text(client.font, parts[1], cx, cy, xC, true); cx += client.font.width(parts[1]);
                graphics.text(client.font, " / ", cx, cy, config.leftStartColor, true); cx += client.font.width(" / ");
                graphics.text(client.font, parts[2], cx, cy, yC, true); cx += client.font.width(parts[2]);
                graphics.text(client.font, " / ", cx, cy, config.leftStartColor, true); cx += client.font.width(" / ");
                graphics.text(client.font, parts[3], cx, cy, zC, true);
            }
            cy += lh;
        }
        return h;
    }

    /** Правая панель: 6 слотов с иконками и прочностью. */
    private static void renderEquipment(GuiGraphicsExtractor graphics, Minecraft client, LocalPlayer player, SparkHUDConfig config, int sw, int sh, int worldHeight) {
        List<ItemStack> items = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        List<Boolean> icons = new ArrayList<>(), texts = new ArrayList<>();
        if (config.showHelmet) { items.add(player.getItemBySlot(EquipmentSlot.HEAD)); labels.add(config.labelHelmet); icons.add(config.showIconHelmet); texts.add(config.showLabelHelmet); }
        if (config.showChest) { items.add(player.getItemBySlot(EquipmentSlot.CHEST)); labels.add(config.labelChest); icons.add(config.showIconChest); texts.add(config.showLabelChest); }
        if (config.showLegs) { items.add(player.getItemBySlot(EquipmentSlot.LEGS)); labels.add(config.labelLegs); icons.add(config.showIconLegs); texts.add(config.showLabelLegs); }
        if (config.showBoots) { items.add(player.getItemBySlot(EquipmentSlot.FEET)); labels.add(config.labelBoots); icons.add(config.showIconBoots); texts.add(config.showLabelBoots); }
        if (config.showMainHand) { items.add(player.getMainHandItem()); labels.add(config.labelMainHand); icons.add(config.showIconMainHand); texts.add(config.showLabelMainHand); }
        if (config.showOffHand) { items.add(player.getOffhandItem()); labels.add(config.labelOffHand); icons.add(config.showIconOffHand); texts.add(config.showLabelOffHand); }
        if (items.isEmpty()) return;

        int p = 4, ls = config.lineSpacing;
        int mw = 0;
        for (int i = 0; i < items.size(); i++) {
            ItemStack s = items.get(i);
            boolean isDmg = !s.isEmpty() && s.getMaxDamage() > 0;
            int w = p;
            if (icons.get(i)) w += 18;
            if (texts.get(i)) w += client.font.width(labels.get(i)) + 5;
            if (isDmg) {
                if (config.durabilityMode == SparkHUDConfig.DurabilityMode.NUMBER) w += client.font.width("0000/0000") + 5;
                else if (config.durabilityMode == SparkHUDConfig.DurabilityMode.PERCENT) w += client.font.width("100%") + 5;
            }
            w += p;
            mw = Math.max(mw, w);
        }
        int h = items.size() * ls + p * 2;

        int x, y;
        if (config.rightAboveWorld && config.rightCorner == SparkHUDConfig.Corner.BOTTOM_LEFT) {
            x = config.rightX;
            y = sh - worldHeight - h - config.rightY;
        } else {
            int[] pos = getCornerPos(config.rightCorner, config.rightX, config.rightY, mw, h, sw, sh);
            x = Math.max(0, Math.min(pos[0], sw - mw));
            y = Math.max(0, Math.min(pos[1], sh - h));
        }

        if (config.showBackground) {
            int alpha = (int)((100 - config.backgroundTransparency) / 100.0 * 255);
            graphics.fill(x, y, x + mw, y + h, (config.backgroundColor & 0xFFFFFF) | (alpha << 24));
        }

        int cy = y + p;
        for (int i = 0; i < items.size(); i++) {
            ItemStack s = items.get(i);
            boolean isDmg = !s.isEmpty() && s.getMaxDamage() > 0;
            int cx = x + p, iconX = cx;

            if (icons.get(i)) {
                if (!s.isEmpty()) graphics.item(s, cx, cy + (ls - 16) / 2);
                cx += 18;
            }
            int ty = cy + (ls - 8) / 2;

            if (texts.get(i)) graphics.text(client.font, labels.get(i), cx, ty, config.rightStartColor, true);

            if (isDmg) {
                float ratio = (float)(s.getMaxDamage() - s.getDamageValue()) / s.getMaxDamage();
                int tS = config.rightStartColor, tE = config.rightEndColor;
                if ((tS & 0xFF000000) == 0) tS |= 0xFF000000;
                if ((tE & 0xFF000000) == 0) tE |= 0xFF000000;

                String durStr = "";
                if (config.durabilityMode == SparkHUDConfig.DurabilityMode.NUMBER)
                    durStr = (s.getMaxDamage() - s.getDamageValue()) + "/" + s.getMaxDamage();
                else if (config.durabilityMode == SparkHUDConfig.DurabilityMode.PERCENT)
                    durStr = (int)(ratio * 100) + "%";
                if (!durStr.isEmpty()) {
                    int durX = x + mw - p - client.font.width(durStr);
                    graphics.text(client.font, durStr, durX, ty, getBarColor(config, 0, ratio, tS, tE), true);
                }

                if (config.durabilityMode == SparkHUDConfig.DurabilityMode.BAR) {
                    int bx1, by1, bx2, by2;
                    switch (config.barPosition) {
                        case BOTTOM -> { bx1 = iconX; by1 = cy + ls - 2; bx2 = iconX + (int)(16 * ratio); by2 = cy + ls; }
                        case TOP -> { bx1 = iconX; by1 = cy; bx2 = iconX + (int)(16 * ratio); by2 = cy + 2; }
                        case LEFT -> { bx1 = iconX - 2; by1 = cy + 2; bx2 = iconX; by2 = cy + ls - 2; }
                        case RIGHT -> { int r = icons.get(i) ? iconX + 18 : iconX; bx1 = r; by1 = cy + 2; bx2 = r + 2; by2 = cy + ls - 2; }
                        case FULL_WIDTH -> { bx1 = x + p; by1 = cy + ls - 2; bx2 = x + p + (int)((mw - p * 2) * ratio); by2 = cy + ls; }
                        default -> { bx1 = iconX; by1 = cy + ls - 2; bx2 = iconX; by2 = cy + ls; }
                    }
                    if (by1 == by2) {
                        for (int j = 0; j < (bx2 - bx1); j++) {
                            float gr = (bx2 - bx1) > 0 ? (float)j / (bx2 - bx1) : 0;
                            graphics.fill(bx1 + j, by1, bx1 + j + 1, by2, getBarColor(config, gr, ratio, tS, tE));
                        }
                    } else {
                        for (int j = 0; j < (by2 - by1); j++) {
                            float gr = (by2 - by1) > 0 ? (float)j / (by2 - by1) : 0;
                            graphics.fill(bx1, by1 + j, bx2, by1 + j + 1, getBarColor(config, gr, ratio, tS, tE));
                        }
                    }
                }
            }
            cy += ls;
        }
    }

    private static void renderCustom(GuiGraphicsExtractor graphics, Minecraft client, SparkHUDConfig.CustomPanel panel) {
        if (!panel.enabled || panel.textLines.isEmpty()) return;
        int padding = 4, lineHeight = 10;
        int height = panel.textLines.size() * lineHeight + padding * 2 + 12;
        int alpha = (int)((100 - panel.transparency) / 100.0 * 255);
        int bg = (panel.bgColor & 0x00FFFFFF) | (alpha << 24);
        int textColor = 0xFF000000 | (panel.textColor & 0x00FFFFFF);
        graphics.fill(panel.x, panel.y, panel.x + panel.width, panel.y + height, bg);
        graphics.text(client.font, panel.title, panel.x + padding, panel.y + padding, textColor, true);
        int cy = panel.y + padding + 12;
        for (String line : panel.textLines) {
            graphics.text(client.font, line, panel.x + padding, cy, textColor, true);
            cy += lineHeight;
        }
    }

    public static int[] getCornerPos(SparkHUDConfig.Corner corner, int offX, int offY, int w, int h, int sw, int sh) {
        return switch (corner) {
            case TOP_LEFT -> new int[]{offX, offY};
            case TOP_RIGHT -> new int[]{sw - w - offX, offY};
            case BOTTOM_LEFT -> new int[]{offX, sh - h - offY};
            case BOTTOM_RIGHT -> new int[]{sw - w - offX, sh - h - offY};
            case CUSTOM -> new int[]{offX, offY};
        };
    }

    private static int getBarColor(SparkHUDConfig config, float gradRatio, float durabilityRatio, int textStart, int textEnd) {
        switch (config.barColorMode) {
            case MATCH_TEXT:
                if (config.rightGradient) return GradientUtils.interpolateColor(textStart, textEnd, gradRatio);
                return textStart;
            case DURABILITY:
                int red = (int)((1.0f - durabilityRatio) * 255);
                int green = (int)(durabilityRatio * 255);
                return 0xFF000000 | (red << 16) | (green << 8);
            case CUSTOM:
            default:
                return GradientUtils.interpolateColor(config.barStartColor, config.barEndColor, gradRatio);
        }
    }
}