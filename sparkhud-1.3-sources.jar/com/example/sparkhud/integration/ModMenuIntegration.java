package com.example.sparkhud.integration;

import com.example.sparkhud.SparkHUDMod;
import com.example.sparkhud.config.ConfigManager;
import com.example.sparkhud.config.SparkHUDConfig;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ModMenuIntegration::createConfigScreen;
    }

    public static Screen createConfigScreen(Screen realParent) {
        boolean[] wantReopen = {false};
        boolean[] openEditor = {false};

        Screen dummy = new Screen(Component.empty()) {
            @Override
            protected void init() {
                Minecraft mc = Minecraft.getInstance();
                if (openEditor[0]) {
                    openEditor[0] = false;
                    mc.gui.setScreen(new DragEditorScreen(realParent));
                } else if (wantReopen[0]) {
                    wantReopen[0] = false;
                    mc.gui.setScreen(createConfigScreen(realParent));
                } else {
                    mc.gui.setScreen(realParent);
                }
            }
        };

        SparkHUDConfig config = SparkHUDMod.CONFIG;
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(dummy)
                .setTitle(Component.literal("Настройки SparkHUD"));
        ConfigEntryBuilder eb = builder.entryBuilder();

        // ========== 1. ИНФОРМАЦИЯ О МИРЕ ==========
        ConfigCategory leftCat = builder.getOrCreateCategory(Component.literal("Информация о мире"));

        // Цвет текста — ПЕРВЫМ
        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ЦВЕТ ТЕКСТА ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Градиент текста"), config.leftGradient).setDefaultValue(true).setSaveConsumer(v -> config.leftGradient = v).build());
        leftCat.addEntry(eb.startColorField(Component.literal("Начало градиента"), config.leftStartColor).setAlphaMode(true).setDefaultValue(0xFFFF7D3D).setSaveConsumer(v -> config.leftStartColor = v).build());
        leftCat.addEntry(eb.startColorField(Component.literal("Конец градиента"), config.leftEndColor).setAlphaMode(true).setDefaultValue(0xFFCC0000).setSaveConsumer(v -> config.leftEndColor = v).build());

        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ КООРДИНАТЫ ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать Координаты"), config.showXyz).setDefaultValue(true).setSaveConsumer(v -> config.showXyz = v).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Цветной XYZ"), config.xyzColors).setDefaultValue(true).setSaveConsumer(v -> config.xyzColors = v).build());
        leftCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelXyz).setDefaultValue("Координаты").setSaveConsumer(v -> config.labelXyz = v).build());

        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ БИОМ ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать Биом"), config.showBiome).setDefaultValue(true).setSaveConsumer(v -> config.showBiome = v).build());
        leftCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelBiome).setDefaultValue("Биом").setSaveConsumer(v -> config.labelBiome = v).build());

        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ПОГОДА ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать Погоду"), config.showWeather).setDefaultValue(true).setSaveConsumer(v -> config.showWeather = v).build());
        leftCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelWeather).setDefaultValue("Погода").setSaveConsumer(v -> config.labelWeather = v).build());

        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ВРЕМЯ В ИГРЕ ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать Время игры"), config.showGameTime).setDefaultValue(true).setSaveConsumer(v -> config.showGameTime = v).build());
        leftCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelGameTime).setDefaultValue("Время игры").setSaveConsumer(v -> config.labelGameTime = v).build());

        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ РЕАЛЬНОЕ ВРЕМЯ ━━━━━")).build());
        leftCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать Реальное время"), config.showRealTime).setDefaultValue(true).setSaveConsumer(v -> config.showRealTime = v).build());
        leftCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelRealTime).setDefaultValue("Время сейчас").setSaveConsumer(v -> config.labelRealTime = v).build());
        leftCat.addEntry(eb.startEnumSelector(Component.literal("Формат даты"), SparkHUDConfig.DateFormat.class, config.dateFormat)
                .setEnumNameProvider(f -> switch ((SparkHUDConfig.DateFormat) f) {
                    case DAY_MONTH -> Component.literal("День-Месяц");
                    case DAY_MONTH_YEAR -> Component.literal("День-Месяц-Год");
                }).setDefaultValue(SparkHUDConfig.DateFormat.DAY_MONTH).setSaveConsumer(v -> config.dateFormat = v).build());
        leftCat.addEntry(eb.startEnumSelector(Component.literal("Формат времени"), SparkHUDConfig.TimeFormat.class, config.timeFormat)
                .setEnumNameProvider(f -> switch ((SparkHUDConfig.TimeFormat) f) {
                    case HMS -> Component.literal("Часы-Минуты-Секунды");
                    case HM -> Component.literal("Часы-Минуты");
                }).setDefaultValue(SparkHUDConfig.TimeFormat.HM).setSaveConsumer(v -> config.timeFormat = v).build());

        // ПОЛОЖЕНИЕ — В САМЫЙ НИЗ
        leftCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ПОЛОЖЕНИЕ ━━━━━")).build());
        leftCat.addEntry(eb.startEnumSelector(Component.literal("Угол"), SparkHUDConfig.Corner.class, config.leftCorner)
                .setEnumNameProvider(p -> switch ((SparkHUDConfig.Corner) p) {
                    case TOP_LEFT -> Component.literal("Слева сверху");
                    case TOP_RIGHT -> Component.literal("Справа сверху");
                    case BOTTOM_LEFT -> Component.literal("Слева снизу");
                    case BOTTOM_RIGHT -> Component.literal("Справа снизу");
                    case CUSTOM -> Component.literal("Свое (X/Y)");
                }).setDefaultValue(SparkHUDConfig.Corner.BOTTOM_LEFT).setSaveConsumer(v -> config.leftCorner = v).build());
        leftCat.addEntry(eb.startIntField(Component.literal("Отступ X"), config.leftX).setDefaultValue(0).setSaveConsumer(v -> config.leftX = v).build());
        leftCat.addEntry(eb.startIntField(Component.literal("Отступ Y"), config.leftY).setDefaultValue(0).setSaveConsumer(v -> config.leftY = v).build());
        leftCat.addEntry(eb.startIntSlider(Component.literal("Высота строк"), config.leftLineSpacing, 10, 30).setDefaultValue(12).setSaveConsumer(v -> config.leftLineSpacing = v).build());

        // ========== 2. СТАТУС ЭКИПИРОВКИ ==========
        ConfigCategory rightCat = builder.getOrCreateCategory(Component.literal("Статус экипировки"));

        // Цвет текста — ПЕРВЫМ
        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ЦВЕТ ТЕКСТА ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Градиент текста"), config.rightGradient).setDefaultValue(true).setSaveConsumer(v -> config.rightGradient = v).build());
        rightCat.addEntry(eb.startColorField(Component.literal("Начало градиента"), config.rightStartColor).setAlphaMode(true).setDefaultValue(0xFFFF7D3D).setSaveConsumer(v -> config.rightStartColor = v).build());
        rightCat.addEntry(eb.startColorField(Component.literal("Конец градиента"), config.rightEndColor).setAlphaMode(true).setDefaultValue(0xFFCC0000).setSaveConsumer(v -> config.rightEndColor = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ПОЛОСКА ПРОЧНОСТИ ━━━━━")).build());
        rightCat.addEntry(eb.startEnumSelector(Component.literal("Режим прочности"), SparkHUDConfig.DurabilityMode.class, config.durabilityMode)
                .setEnumNameProvider(m -> switch ((SparkHUDConfig.DurabilityMode) m) {
                    case NUMBER -> Component.literal("Цифры");
                    case PERCENT -> Component.literal("Проценты");
                    case BAR -> Component.literal("Полоска");
                    case HIDDEN -> Component.literal("Скрыть");
                }).setDefaultValue(SparkHUDConfig.DurabilityMode.BAR).setSaveConsumer(v -> config.durabilityMode = v).build());
        rightCat.addEntry(eb.startEnumSelector(Component.literal("Позиция полоски"), SparkHUDConfig.BarPosition.class, config.barPosition)
                .setEnumNameProvider(p -> switch ((SparkHUDConfig.BarPosition) p) {
                    case BOTTOM -> Component.literal("Снизу");
                    case TOP -> Component.literal("Сверху");
                    case RIGHT -> Component.literal("Справа");
                    case LEFT -> Component.literal("Слева");
                    case FULL_WIDTH -> Component.literal("На всю ширину строки");
                }).setDefaultValue(SparkHUDConfig.BarPosition.FULL_WIDTH).setSaveConsumer(v -> config.barPosition = v).build());
        rightCat.addEntry(eb.startEnumSelector(Component.literal("Цвет полоски и цифр"), SparkHUDConfig.BarColorMode.class, config.barColorMode)
                .setEnumNameProvider(m -> switch ((SparkHUDConfig.BarColorMode) m) {
                    case CUSTOM -> Component.literal("Свой цвет");
                    case MATCH_TEXT -> Component.literal("Как у текста");
                    case DURABILITY -> Component.literal("Запас прочности");
                }).setDefaultValue(SparkHUDConfig.BarColorMode.DURABILITY).setSaveConsumer(v -> config.barColorMode = v).build());
        rightCat.addEntry(eb.startColorField(Component.literal("Начало градиента"), config.barStartColor).setAlphaMode(true).setDefaultValue(0xFFF35520).setSaveConsumer(v -> config.barStartColor = v).build());
        rightCat.addEntry(eb.startColorField(Component.literal("Конец градиента"), config.barEndColor).setAlphaMode(true).setDefaultValue(0xFFE8D030).setSaveConsumer(v -> config.barEndColor = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ШЛЕМ ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showHelmet).setDefaultValue(true).setSaveConsumer(v -> config.showHelmet = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconHelmet).setDefaultValue(true).setSaveConsumer(v -> config.showIconHelmet = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelHelmet).setDefaultValue(true).setSaveConsumer(v -> config.showLabelHelmet = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelHelmet).setDefaultValue("Шлем").setSaveConsumer(v -> config.labelHelmet = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ НАГРУДНИК ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showChest).setDefaultValue(true).setSaveConsumer(v -> config.showChest = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconChest).setDefaultValue(true).setSaveConsumer(v -> config.showIconChest = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelChest).setDefaultValue(true).setSaveConsumer(v -> config.showLabelChest = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelChest).setDefaultValue("Нагрудник").setSaveConsumer(v -> config.labelChest = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ШТАНЫ ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showLegs).setDefaultValue(true).setSaveConsumer(v -> config.showLegs = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconLegs).setDefaultValue(true).setSaveConsumer(v -> config.showIconLegs = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelLegs).setDefaultValue(true).setSaveConsumer(v -> config.showLabelLegs = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelLegs).setDefaultValue("Штаны").setSaveConsumer(v -> config.labelLegs = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ БОТИНКИ ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showBoots).setDefaultValue(true).setSaveConsumer(v -> config.showBoots = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconBoots).setDefaultValue(true).setSaveConsumer(v -> config.showIconBoots = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelBoots).setDefaultValue(true).setSaveConsumer(v -> config.showLabelBoots = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelBoots).setDefaultValue("Ботинки").setSaveConsumer(v -> config.labelBoots = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ В РУКЕ ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showMainHand).setDefaultValue(true).setSaveConsumer(v -> config.showMainHand = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconMainHand).setDefaultValue(true).setSaveConsumer(v -> config.showIconMainHand = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelMainHand).setDefaultValue(true).setSaveConsumer(v -> config.showLabelMainHand = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelMainHand).setDefaultValue("В руке").setSaveConsumer(v -> config.labelMainHand = v).build());

        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ВО 2-Й РУКЕ ━━━━━")).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать слот"), config.showOffHand).setDefaultValue(true).setSaveConsumer(v -> config.showOffHand = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать иконку"), config.showIconOffHand).setDefaultValue(true).setSaveConsumer(v -> config.showIconOffHand = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать текст"), config.showLabelOffHand).setDefaultValue(true).setSaveConsumer(v -> config.showLabelOffHand = v).build());
        rightCat.addEntry(eb.startStrField(Component.literal("Изменить текст"), config.labelOffHand).setDefaultValue("Во 2-й руке").setSaveConsumer(v -> config.labelOffHand = v).build());

        // ПОЛОЖЕНИЕ — В КОНЕЦ
        rightCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ПОЛОЖЕНИЕ ━━━━━")).build());
        rightCat.addEntry(eb.startEnumSelector(Component.literal("Угол"), SparkHUDConfig.Corner.class, config.rightCorner)
                .setEnumNameProvider(p -> switch ((SparkHUDConfig.Corner) p) {
                    case TOP_LEFT -> Component.literal("Слева сверху");
                    case TOP_RIGHT -> Component.literal("Справа сверху");
                    case BOTTOM_LEFT -> Component.literal("Слева снизу");
                    case BOTTOM_RIGHT -> Component.literal("Справа снизу");
                    case CUSTOM -> Component.literal("Свое (X/Y)");
                }).setDefaultValue(SparkHUDConfig.Corner.BOTTOM_LEFT).setSaveConsumer(v -> config.rightCorner = v).build());
        rightCat.addEntry(eb.startBooleanToggle(Component.literal("Панель над панелью мира"), config.rightAboveWorld).setDefaultValue(true).setSaveConsumer(v -> config.rightAboveWorld = v).build());
        rightCat.addEntry(eb.startIntField(Component.literal("Отступ X"), config.rightX).setDefaultValue(0).setSaveConsumer(v -> config.rightX = v).build());
        rightCat.addEntry(eb.startIntField(Component.literal("Отступ Y"), config.rightY).setDefaultValue(0).setSaveConsumer(v -> config.rightY = v).build());
        rightCat.addEntry(eb.startIntSlider(Component.literal("Высота строк"), config.lineSpacing, 16, 32).setDefaultValue(20).setSaveConsumer(v -> config.lineSpacing = v).build());

        // ========== 3. ГАММА / НОЧНОЕ ЗРЕНИЕ ==========
        ConfigCategory gnvCat = builder.getOrCreateCategory(Component.literal("Гамма / Ночное зрение"));

        gnvCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ГАММА ━━━━━")).build());
        gnvCat.addEntry(eb.startBooleanToggle(Component.literal("Включить гамму (G)"), config.gammaEnabled).setDefaultValue(false).setSaveConsumer(v -> config.gammaEnabled = v).build());
        gnvCat.addEntry(eb.startIntSlider(Component.literal("Целевая гамма"), config.gammaTargetPercent / 10, 0, 25)
                .setDefaultValue(25).setSaveConsumer(v -> config.gammaTargetPercent = v * 10)
                .setTextGetter(v -> Component.literal((v * 10) + "%"))
                .build());
        gnvCat.addEntry(eb.startBooleanToggle(Component.literal("Плавный переход"), config.gammaSmooth).setDefaultValue(true).setSaveConsumer(v -> config.gammaSmooth = v).build());
        gnvCat.addEntry(eb.startIntSlider(Component.literal("Время перехода"), (int)(config.gammaTransitionTime * 10), 0, 50)
                .setDefaultValue(20).setSaveConsumer(v -> config.gammaTransitionTime = v / 10f)
                .setTextGetter(v -> Component.literal(String.format("%.1f сек", v / 10f)))
                .build());

        gnvCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ НОЧНОЕ ЗРЕНИЕ ━━━━━")).build());
        gnvCat.addEntry(eb.startBooleanToggle(Component.literal("Включить ночное зрение (H)"), config.nightVisionEnabled).setDefaultValue(false).setSaveConsumer(v -> config.nightVisionEnabled = v).build());
        gnvCat.addEntry(eb.startBooleanToggle(Component.literal("Плавный переход"), config.nightVisionSmooth).setDefaultValue(true).setSaveConsumer(v -> config.nightVisionSmooth = v).build());
        gnvCat.addEntry(eb.startIntSlider(Component.literal("Время перехода"), (int)(config.nightVisionTransitionTime * 10), 0, 50)
                .setDefaultValue(20).setSaveConsumer(v -> config.nightVisionTransitionTime = v / 10f)
                .setTextGetter(v -> Component.literal(String.format("%.1f сек", v / 10f)))
                .build());

        // ========== 4. ОБЩИЙ ВИД ==========
        ConfigCategory visualCat = builder.getOrCreateCategory(Component.literal("Общий вид"));

        visualCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ФОН ━━━━━")).build());
        visualCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать фон"), config.showBackground).setDefaultValue(true).setSaveConsumer(v -> config.showBackground = v).build());
        visualCat.addEntry(eb.startIntSlider(Component.literal("Прозрачность фона (%)"), config.backgroundTransparency, 0, 100).setDefaultValue(95).setSaveConsumer(v -> config.backgroundTransparency = v).build());
        visualCat.addEntry(eb.startColorField(Component.literal("Цвет фона"), config.backgroundColor).setAlphaMode(false).setDefaultValue(0xFECC76).setSaveConsumer(v -> config.backgroundColor = v).build());

        visualCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ РАМКА ━━━━━")).build());
        visualCat.addEntry(eb.startBooleanToggle(Component.literal("Показывать рамку"), config.showFrame).setDefaultValue(true).setSaveConsumer(v -> config.showFrame = v).build());
        visualCat.addEntry(eb.startIntSlider(Component.literal("Толщина рамки"), config.frameThickness, 1, 10).setDefaultValue(1).setSaveConsumer(v -> config.frameThickness = v).build());
        visualCat.addEntry(eb.startIntSlider(Component.literal("Прозрачность рамки (%)"), config.frameTransparency, 0, 100).setDefaultValue(95).setSaveConsumer(v -> config.frameTransparency = v).build());
        visualCat.addEntry(eb.startColorField(Component.literal("Цвет рамки"), config.frameColor).setAlphaMode(false).setDefaultValue(0xF17532).setSaveConsumer(v -> config.frameColor = v).build());

        // ========== 5. ПОЛЬЗОВАТЕЛЬСКИЕ ПАНЕЛИ (разделители ОРАНЖЕВЫЕ) ==========
        ConfigCategory customCat = builder.getOrCreateCategory(Component.literal("Пользовательские панели"));
        int n = config.customPanels.size();
        boolean[] deleteFlags = new boolean[n];
        boolean[] addNewPanel = {false};

        for (int i = 0; i < n; i++) {
            final int idx = i;
            SparkHUDConfig.CustomPanel p = config.customPanels.get(i);
            // Оранжевый §6 вместо жёлтого §e
            customCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ПАНЕЛЬ " + (i + 1) + " ━━━━━")).build());
            customCat.addEntry(eb.startBooleanToggle(Component.literal("Включить"), p.enabled).setDefaultValue(false).setSaveConsumer(v -> p.enabled = v).build());
            customCat.addEntry(eb.startStrField(Component.literal("Заголовок"), p.title).setDefaultValue("Новая панель").setSaveConsumer(v -> p.title = v).build());
            customCat.addEntry(eb.startStrList(Component.literal("Текст (To-Do)"), p.textLines).setDefaultValue(new ArrayList<>(List.of("Строка 1", "Строка 2"))).setSaveConsumer(v -> p.textLines = v).build());
            customCat.addEntry(eb.startIntField(Component.literal("X"), p.x).setDefaultValue(50).setSaveConsumer(v -> p.x = v).build());
            customCat.addEntry(eb.startIntField(Component.literal("Y"), p.y).setDefaultValue(50).setSaveConsumer(v -> p.y = v).build());
            customCat.addEntry(eb.startIntField(Component.literal("Ширина"), p.width).setDefaultValue(120).setSaveConsumer(v -> p.width = v).build());
            customCat.addEntry(eb.startIntSlider(Component.literal("Прозрачность (%)"), p.transparency, 0, 100).setDefaultValue(95).setSaveConsumer(v -> p.transparency = v).build());
            customCat.addEntry(eb.startColorField(Component.literal("Цвет фона"), p.bgColor).setAlphaMode(false).setDefaultValue(0x808080).setSaveConsumer(v -> p.bgColor = v).build());
            customCat.addEntry(eb.startColorField(Component.literal("Цвет текста"), p.textColor).setAlphaMode(false).setDefaultValue(0xFFFFFF).setSaveConsumer(v -> p.textColor = v).build());
            customCat.addEntry(eb.startBooleanToggle(Component.literal("§cУдалить эту панель"), false)
                    .setDefaultValue(false)
                    .setSaveConsumer(v -> deleteFlags[idx] = v).build());
        }

        customCat.addEntry(eb.startTextDescription(Component.literal("§6§l━━━━━ ДОБАВИТЬ ПАНЕЛЬ ━━━━━")).build());
        customCat.addEntry(eb.startBooleanToggle(Component.literal("Добавить новую панель (включите и нажмите Сохранить)"), false)
                .setDefaultValue(false)
                .setSaveConsumer(v -> addNewPanel[0] = v).build());

        // ========== 6. РЕДАКТОР ==========
        ConfigCategory editorCat = builder.getOrCreateCategory(Component.literal("Редактор позиций"));
        editorCat.addEntry(eb.startBooleanToggle(Component.literal("Открыть редактор (вкл → откроется)"), false)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Включите, чтобы перетаскивать все панели мышкой"))
                .setSaveConsumer(v -> openEditor[0] = v).build());

        builder.setSavingRunnable(() -> {
            for (int i = n - 1; i >= 0; i--) {
                if (deleteFlags[i]) config.customPanels.remove(i);
            }
            if (addNewPanel[0]) config.customPanels.add(new SparkHUDConfig.CustomPanel());
            Minecraft mc = Minecraft.getInstance();
            config.savedScreenWidth = mc.getWindow().getGuiScaledWidth();
            config.savedScreenHeight = mc.getWindow().getGuiScaledHeight();
            ConfigManager.save(config);
            if (!openEditor[0]) wantReopen[0] = true;
        });

        return builder.build();
    }
}