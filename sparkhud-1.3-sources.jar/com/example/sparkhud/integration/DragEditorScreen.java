package com.example.sparkhud.integration;

import com.example.sparkhud.SparkHUDMod;
import com.example.sparkhud.config.ConfigManager;
import com.example.sparkhud.config.SparkHUDConfig;
import com.example.sparkhud.hud.HudRenderer;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class DragEditorScreen extends Screen {
    private final Screen parentScreen;
    private int dragging = -1;
    private int activePanel = -1;
    private float dragOffX, dragOffY;
    private boolean wasLeft, wasRight, wasUp, wasDown;

    private int N = 0;
    private float[] posX;
    private float[] posY;
    private int[] widths;
    private int[] heights;
    private String[] titles;
    private boolean[] enabled;
    private int[] colors;

    private float[] origX;
    private float[] origY;

    public DragEditorScreen(Screen parentScreen) {
        super(Component.literal("Редактор панелей"));
        this.parentScreen = parentScreen;
    }

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        SparkHUDConfig c = SparkHUDMod.CONFIG;
        int sw = this.width, sh = this.height;
        N = 2 + c.customPanels.size();

        posX = new float[N]; posY = new float[N]; widths = new int[N]; heights = new int[N];
        titles = new String[N]; enabled = new boolean[N]; colors = new int[N];
        origX = new float[N]; origY = new float[N];

        titles[0] = "Информация о мире"; enabled[0] = true; colors[0] = 0xFFFF7D3D;
        int worldRows = 0, worldMaxW = 50;
        if (c.showXyz) { worldRows++; worldMaxW = Math.max(worldMaxW, mc.font.width(c.labelXyz + ": 000.0 / 64.0 / 000.0")); }
        if (c.showBiome) { worldRows++; worldMaxW = Math.max(worldMaxW, mc.font.width(c.labelBiome + ": Тайга")); }
        if (c.showWeather) { worldRows++; worldMaxW = Math.max(worldMaxW, mc.font.width(c.labelWeather + ": Гроза")); }
        if (c.showGameTime) { worldRows++; worldMaxW = Math.max(worldMaxW, mc.font.width(c.labelGameTime + ": 00:00")); }
        if (c.showRealTime) { worldRows++; worldMaxW = Math.max(worldMaxW, mc.font.width(c.labelRealTime + ": 01.01.2026 12:00")); }
        widths[0] = worldMaxW + 8;
        heights[0] = Math.max(1, worldRows) * c.leftLineSpacing + 8;
        int[] p0 = HudRenderer.getCornerPos(c.leftCorner, c.leftX, c.leftY, widths[0], heights[0], sw, sh);
        posX[0] = p0[0]; posY[0] = p0[1];

        titles[1] = "Статус экипировки"; enabled[1] = true; colors[1] = 0xFFFF5555;
        int equipRows = 0, equipMaxW = 40;
        String[] names = {c.labelHelmet, c.labelChest, c.labelLegs, c.labelBoots, c.labelMainHand, c.labelOffHand};
        boolean[] shows = {c.showHelmet, c.showChest, c.showLegs, c.showBoots, c.showMainHand, c.showOffHand};
        boolean[] showsLabels = {c.showLabelHelmet, c.showLabelChest, c.showLabelLegs, c.showLabelBoots, c.showLabelMainHand, c.showLabelOffHand};
        boolean[] showsIcons = {c.showIconHelmet, c.showIconChest, c.showIconLegs, c.showIconBoots, c.showIconMainHand, c.showIconOffHand};
        for (int i = 0; i < 6; i++) {
            if (!shows[i]) continue;
            equipRows++;
            int w = 4;
            if (showsIcons[i]) w += 18;
            if (showsLabels[i]) w += mc.font.width(names[i]) + 5;
            if (c.durabilityMode == SparkHUDConfig.DurabilityMode.NUMBER) w += mc.font.width("0000/0000") + 5;
            else if (c.durabilityMode == SparkHUDConfig.DurabilityMode.PERCENT) w += mc.font.width("100%") + 5;
            w += 4;
            equipMaxW = Math.max(equipMaxW, w);
        }
        widths[1] = equipMaxW;
        heights[1] = Math.max(1, equipRows) * c.lineSpacing + 8;
        if (c.rightAboveWorld && c.rightCorner == SparkHUDConfig.Corner.BOTTOM_LEFT) {
            posX[1] = c.rightX;
            posY[1] = sh - heights[0] - heights[1] - c.rightY;
        } else {
            int[] p1 = HudRenderer.getCornerPos(c.rightCorner, c.rightX, c.rightY, widths[1], heights[1], sw, sh);
            posX[1] = p1[0]; posY[1] = p1[1];
        }

        for (int i = 0; i < c.customPanels.size(); i++) {
            int idx = 2 + i;
            SparkHUDConfig.CustomPanel panel = c.customPanels.get(i);
            posX[idx] = panel.x;
            posY[idx] = panel.y;
            widths[idx] = panel.width;
            heights[idx] = panel.textLines.size() * 10 + 26;
            titles[idx] = panel.title;
            enabled[idx] = panel.enabled;
            colors[idx] = panel.textColor;
        }

        System.arraycopy(posX, 0, origX, 0, N);
        System.arraycopy(posY, 0, origY, 0, N);
        clampAll();
    }

    private void clampAll() {
        for (int i = 0; i < N; i++) {
            if (!enabled[i]) continue;
            posX[i] = Math.max(0, Math.min(posX[i], this.width - widths[i]));
            posY[i] = Math.max(0, Math.min(posY[i], this.height - heights[i]));
        }
    }

    @Override
    public void tick() {
        boolean left = InputConstants.isKeyDown(InputConstants.KEY_LEFT);
        boolean right = InputConstants.isKeyDown(InputConstants.KEY_RIGHT);
        boolean up = InputConstants.isKeyDown(InputConstants.KEY_UP);
        boolean down = InputConstants.isKeyDown(InputConstants.KEY_DOWN);
        int dx = 0, dy = 0;
        if (left && !wasLeft) dx -= 1;
        if (right && !wasRight) dx += 1;
        if (up && !wasUp) dy -= 1;
        if (down && !wasDown) dy += 1;
        wasLeft = left; wasRight = right; wasUp = up; wasDown = down;
        if ((dx == 0 && dy == 0) || activePanel == -1) return;
        boolean shift = InputConstants.isKeyDown(InputConstants.KEY_LSHIFT) || InputConstants.isKeyDown(InputConstants.KEY_RSHIFT);
        if (shift) { dx *= 5; dy *= 5; }
        posX[activePanel] = Math.max(0, Math.min(posX[activePanel] + dx, this.width - widths[activePanel]));
        posY[activePanel] = Math.max(0, Math.min(posY[activePanel] + dy, this.height - heights[activePanel]));
    }

    private static final int BTN_W = 240, BTN_H = 28, BTN_GAP = 10;
    private static final int BOTTOM_MARGIN = 30;

    private int[] getButtonPositions() {
        int totalH = BTN_H * 3 + BTN_GAP * 2;
        int btnX = (this.width - BTN_W) / 2;
        int btnY = this.height - BOTTOM_MARGIN - totalH;
        return new int[]{
                btnX, btnY,
                btnX, btnY + BTN_H + BTN_GAP,
                btnX, btnY + (BTN_H + BTN_GAP) * 2
        };
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        if (dragging != -1) {
            float nx = mouseX - dragOffX;
            float ny = mouseY - dragOffY;
            if (nx < 10) nx = 0;
            if (ny < 10) ny = 0;
            if (nx > this.width - widths[dragging] - 10) nx = this.width - widths[dragging];
            if (ny > this.height - heights[dragging] - 10) ny = this.height - heights[dragging];
            posX[dragging] = Math.max(0, Math.min(nx, this.width - widths[dragging]));
            posY[dragging] = Math.max(0, Math.min(ny, this.height - heights[dragging]));
        }

        graphics.fill(0, 0, this.width, this.height, 0x80000000);
        graphics.text(this.font, "§e§lРедактор позиций", 20, 20, 0xFFFFFFFF, true);
        graphics.text(this.font, "§7Клик — выбрать. Тяните мышью. Стрелки — шаг 1. Shift+стрелки — шаг 5.", 20, 36, 0xFFAAAAAA, true);

        for (int i = 0; i < N; i++) {
            if (enabled[i]) drawPanel(graphics, i);
        }

        int[] bp = getButtonPositions();
        drawButton(graphics, bp[0], bp[1], "Сохранить", mouseX, mouseY);
        drawButton(graphics, bp[2], bp[3], "Сбросить", mouseX, mouseY);
        drawButton(graphics, bp[4], bp[5], "Выйти без сохранения", mouseX, mouseY);
    }

    private void drawButton(GuiGraphicsExtractor g, int x, int y, String label, int mouseX, int mouseY) {
        boolean hover = mouseX >= x && mouseX <= x + BTN_W && mouseY >= y && mouseY <= y + BTN_H;
        g.fill(x, y, x + BTN_W, y + BTN_H, hover ? 0xFF7A7A7A : 0xFF4A4A4A);
        g.fill(x, y, x + BTN_W, y + 1, 0xFFFFFFFF);
        g.fill(x, y + BTN_H - 1, x + BTN_W, y + BTN_H, 0xFFFFFFFF);
        g.fill(x, y, x + 1, y + BTN_H, 0xFFFFFFFF);
        g.fill(x + BTN_W - 1, y, x + BTN_W, y + BTN_H, 0xFFFFFFFF);
        int tw = this.font.width(label);
        g.text(this.font, label, x + (BTN_W - tw) / 2, y + (BTN_H - 8) / 2, 0xFFFFFFFF, true);
    }

    private void drawPanel(GuiGraphicsExtractor g, int i) {
        int x = (int)posX[i], y = (int)posY[i], w = widths[i], h = heights[i];
        boolean act = (activePanel == i || dragging == i);
        g.fill(x, y, x + w, y + h, act ? 0xE6000000 : 0xA0000000);
        int border = act ? 0xFFFFAA00 : colors[i];
        int t = act ? 3 : 2;
        g.fill(x, y, x + w, y + t, border); g.fill(x, y + h - t, x + w, y + h, border);
        g.fill(x, y, x + t, y + h, border); g.fill(x + w - t, y, x + w, y + h, border);

        SparkHUDConfig c = SparkHUDMod.CONFIG;
        int p = 4;
        if (i == 0) {
            int cy = y + p;
            if (c.showXyz) { g.text(this.font, c.labelXyz + ": 100.0 / 64.0 / 100.0", x + p, cy, colors[0], true); cy += c.leftLineSpacing; }
            if (c.showBiome) { g.text(this.font, c.labelBiome + ": Тайга", x + p, cy, colors[0], true); cy += c.leftLineSpacing; }
            if (c.showWeather) { g.text(this.font, c.labelWeather + ": Ясно", x + p, cy, colors[0], true); cy += c.leftLineSpacing; }
            if (c.showGameTime) { g.text(this.font, c.labelGameTime + ": 12:00", x + p, cy, colors[0], true); cy += c.leftLineSpacing; }
            if (c.showRealTime) { g.text(this.font, c.labelRealTime + ": 01.01.2026 12:00", x + p, cy, colors[0], true); }
        } else if (i == 1) {
            int cy = y + p;
            String[] names = {c.labelHelmet, c.labelChest, c.labelLegs, c.labelBoots, c.labelMainHand, c.labelOffHand};
            boolean[] shows = {c.showHelmet, c.showChest, c.showLegs, c.showBoots, c.showMainHand, c.showOffHand};
            boolean[] showsIcons = {c.showIconHelmet, c.showIconChest, c.showIconLegs, c.showIconBoots, c.showIconMainHand, c.showIconOffHand};
            boolean[] showsLabels = {c.showLabelHelmet, c.showLabelChest, c.showLabelLegs, c.showLabelBoots, c.showLabelMainHand, c.showLabelOffHand};
            for (int j = 0; j < 6; j++) {
                if (!shows[j]) continue;
                int cx = x + p;
                if (showsIcons[j]) { g.fill(cx, cy + (c.lineSpacing - 16) / 2, cx + 16, cy + (c.lineSpacing - 16) / 2 + 16, 0xFF888888); cx += 18; }
                int ty = cy + (c.lineSpacing - 8) / 2;
                if (showsLabels[j]) g.text(this.font, names[j], cx, ty, colors[1], true);
                cy += c.lineSpacing;
            }
        } else {
            SparkHUDConfig.CustomPanel panel = c.customPanels.get(i - 2);
            int textColor = 0xFF000000 | (panel.textColor & 0x00FFFFFF);
            g.text(this.font, panel.title, x + p, y + p, 0xFFFFAA00, true);
            int cy = y + p + 12;
            for (String line : panel.textLines) {
                g.text(this.font, line, x + p, cy, textColor, true);
                cy += 10;
            }
        }

        g.text(this.font, titles[i], x + (w - this.font.width(titles[i])) / 2, y + 6, 0xFFFFAA00, true);
        g.text(this.font, "X: " + x + " Y: " + y, x + (w - this.font.width("X: " + x + " Y: " + y)) / 2, y + h - 18, 0xFFFFFFFF, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean dbl) {
        double mx = event.x(), my = event.y();
        int[] bp = getButtonPositions();

        if (mx >= bp[4] && mx <= bp[4] + BTN_W && my >= bp[5] && my <= bp[5] + BTN_H) {
            Minecraft.getInstance().gui.setScreen(parentScreen);
            return true;
        }
        if (mx >= bp[2] && mx <= bp[2] + BTN_W && my >= bp[3] && my <= bp[3] + BTN_H) {
            System.arraycopy(origX, 0, posX, 0, N);
            System.arraycopy(origY, 0, posY, 0, N);
            clampAll();
            return true;
        }
        if (mx >= bp[0] && mx <= bp[0] + BTN_W && my >= bp[1] && my <= bp[1] + BTN_H) {
            saveAndClose();
            return true;
        }

        for (int i = 0; i < N; i++) {
            if (enabled[i] && mx >= posX[i] && mx <= posX[i] + widths[i] && my >= posY[i] && my <= posY[i] + heights[i]) {
                activePanel = i; dragging = i;
                dragOffX = (float)(mx - posX[i]); dragOffY = (float)(my - posY[i]);
                return true;
            }
        }
        activePanel = -1;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != -1) {
            float nx = (float)event.x() - dragOffX;
            float ny = (float)event.y() - dragOffY;
            if (nx < 10) nx = 0;
            if (ny < 10) ny = 0;
            if (nx > this.width - widths[dragging] - 10) nx = this.width - widths[dragging];
            if (ny > this.height - heights[dragging] - 10) ny = this.height - heights[dragging];
            posX[dragging] = Math.max(0, Math.min(nx, this.width - widths[dragging]));
            posY[dragging] = Math.max(0, Math.min(ny, this.height - heights[dragging]));
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = -1; clampAll(); return false;
    }

    @Override
    public void onClose() { saveAndClose(); }

    private void saveAndClose() {
        clampAll();
        SparkHUDConfig c = SparkHUDMod.CONFIG;
        int sw = this.width, sh = this.height;
        int th = 10;

        // Левая панель
        if (posX[0] < th && posY[0] < th) {
            c.leftCorner = SparkHUDConfig.Corner.TOP_LEFT; c.leftX = (int)posX[0]; c.leftY = (int)posY[0];
        } else if (posX[0] > sw - widths[0] - th && posY[0] < th) {
            c.leftCorner = SparkHUDConfig.Corner.TOP_RIGHT; c.leftX = (int)(sw - widths[0] - posX[0]); c.leftY = (int)posY[0];
        } else if (posX[0] < th && posY[0] > sh - heights[0] - th) {
            c.leftCorner = SparkHUDConfig.Corner.BOTTOM_LEFT; c.leftX = (int)posX[0]; c.leftY = (int)(sh - heights[0] - posY[0]);
        } else if (posX[0] > sw - widths[0] - th && posY[0] > sh - heights[0] - th) {
            c.leftCorner = SparkHUDConfig.Corner.BOTTOM_RIGHT; c.leftX = (int)(sw - widths[0] - posX[0]); c.leftY = (int)(sh - heights[0] - posY[0]);
        } else {
            c.leftCorner = SparkHUDConfig.Corner.CUSTOM; c.leftX = (int)posX[0]; c.leftY = (int)posY[0];
        }

        // Правая панель
        if (posX[1] < th && posY[1] < th) {
            c.rightCorner = SparkHUDConfig.Corner.TOP_LEFT; c.rightX = (int)posX[1]; c.rightY = (int)posY[1];
        } else if (posX[1] > sw - widths[1] - th && posY[1] < th) {
            c.rightCorner = SparkHUDConfig.Corner.TOP_RIGHT; c.rightX = (int)(sw - widths[1] - posX[1]); c.rightY = (int)posY[1];
        } else if (posX[1] < th && posY[1] > sh - heights[1] - th) {
            c.rightCorner = SparkHUDConfig.Corner.BOTTOM_LEFT; c.rightX = (int)posX[1]; c.rightY = (int)(sh - heights[1] - posY[1]);
        } else if (posX[1] > sw - widths[1] - th && posY[1] > sh - heights[1] - th) {
            c.rightCorner = SparkHUDConfig.Corner.BOTTOM_RIGHT; c.rightX = (int)(sw - widths[1] - posX[1]); c.rightY = (int)(sh - heights[1] - posY[1]);
        } else {
            c.rightCorner = SparkHUDConfig.Corner.CUSTOM; c.rightX = (int)posX[1]; c.rightY = (int)posY[1];
        }

        c.rightAboveWorld = false;

        for (int i = 0; i < c.customPanels.size(); i++) {
            int idx = 2 + i;
            SparkHUDConfig.CustomPanel panel = c.customPanels.get(i);
            panel.x = (int)posX[idx];
            panel.y = (int)posY[idx];
        }

        c.savedScreenWidth = sw;
        c.savedScreenHeight = sh;
        ConfigManager.save(c);
        Minecraft.getInstance().gui.setScreen(parentScreen);
    }
}