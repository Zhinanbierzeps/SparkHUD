package com.example.sparkhud.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Класс конфигурации мода SparkHUD.
 * Все поля сериализуются в JSON через Gson (см. ConfigManager).
 * Значения по умолчанию применяются при первом запуске.
 */
public class SparkHUDConfig {
    // Угол экрана, к которому привязана панель
    public enum Corner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, CUSTOM }
    // Режим отображения прочности предмета
    public enum DurabilityMode { NUMBER, PERCENT, BAR, HIDDEN }
    // Позиция полоски прочности относительно иконки
    public enum BarPosition { BOTTOM, TOP, RIGHT, LEFT, FULL_WIDTH }
    // Режим цвета полоски прочности
    public enum BarColorMode { CUSTOM, MATCH_TEXT, DURABILITY }
    // Формат даты в панели реального времени
    public enum DateFormat { DAY_MONTH, DAY_MONTH_YEAR }
    // Формат времени в панели реального времени
    public enum TimeFormat { HMS, HM }

    /**
     * Пользовательская панель (To-Do лист).
     * Игрок может добавлять/удалять такие панели в меню настроек.
     */
    public static class CustomPanel {
        public boolean enabled = false;           // показывать панель в HUD
        public String title = "Новая панель";     // заголовок
        public int x = 50;                        // позиция по X
        public int y = 50;                        // позиция по Y
        public int width = 120;                   // ширина панели
        public int transparency = 95;             // прозрачность фона, %
        public int bgColor = 0x808080;            // цвет фона (серый по умолчанию)
        public int textColor = 0xFFFFFF;          // цвет текста (белый)
        public List<String> textLines = new ArrayList<>(List.of("Строка 1", "Строка 2"));
    }

    // Список пользовательских панелей (по умолчанию 3 штуки)
    public List<CustomPanel> customPanels = new ArrayList<>(List.of(
            new CustomPanel(), new CustomPanel(), new CustomPanel()));

    // ============ ЛЕВАЯ ПАНЕЛЬ (Информация о мире) ============
    public Corner leftCorner = Corner.BOTTOM_LEFT;      // угол привязки
    public int leftX = 0;                                // отступ по X
    public int leftY = 0;                                // отступ по Y
    public int leftLineSpacing = 12;                     // высота строки
    public int leftStartColor = 0xFFFF7D3D;              // начало градиента
    public int leftEndColor = 0xFFCC0000;                // конец градиента
    public boolean leftGradient = true;                  // включён ли градиент
    public boolean xyzColors = true;                     // цветной XYZ (красный/зелёный/синий)

    // Видимость отдельных строк в левой панели
    public boolean showXyz = true;
    public boolean showBiome = true;
    public boolean showWeather = true;
    public boolean showGameTime = true;
    public boolean showRealTime = true;

    // Названия строк (можно менять в настройках)
    public String labelXyz = "Координаты";
    public String labelBiome = "Биом";
    public String labelWeather = "Погода";
    public String labelGameTime = "Время игры";
    public String labelRealTime = "Время сейчас";

    // Форматы
    public DateFormat dateFormat = DateFormat.DAY_MONTH;   // дд.мм по умолчанию
    public TimeFormat timeFormat = TimeFormat.HM;          // чч:мм по умолчанию

    // ============ ПРАВАЯ ПАНЕЛЬ (Статус экипировки) ============
    public Corner rightCorner = Corner.BOTTOM_LEFT;      // угол привязки
    public int rightX = 0;                                // отступ X
    public int rightY = 0;                                // отступ Y
    public boolean rightAboveWorld = true;                // панель над панелью мира (для BOTTOM_LEFT)
    public int rightStartColor = 0xFFFF7D3D;              // цвет текста — начало
    public int rightEndColor = 0xFFCC0000;                // цвет текста — конец
    public boolean rightGradient = true;                  // градиент включён

    // Настройки каждого слота: показывать/иконка/текст/название
    public boolean showHelmet = true;
    public boolean showIconHelmet = true;
    public boolean showLabelHelmet = true;
    public String labelHelmet = "Шлем";

    public boolean showChest = true;
    public boolean showIconChest = true;
    public boolean showLabelChest = true;
    public String labelChest = "Нагрудник";

    public boolean showLegs = true;
    public boolean showIconLegs = true;
    public boolean showLabelLegs = true;
    public String labelLegs = "Штаны";

    public boolean showBoots = true;
    public boolean showIconBoots = true;
    public boolean showLabelBoots = true;
    public String labelBoots = "Ботинки";

    public boolean showMainHand = true;
    public boolean showIconMainHand = true;
    public boolean showLabelMainHand = true;
    public String labelMainHand = "В руке";

    public boolean showOffHand = true;
    public boolean showIconOffHand = true;
    public boolean showLabelOffHand = true;
    public String labelOffHand = "Во 2-й руке";

    // ============ ПРОЧНОСТЬ ============
    public DurabilityMode durabilityMode = DurabilityMode.BAR;        // режим отображения
    public BarPosition barPosition = BarPosition.FULL_WIDTH;          // где рисовать полоску
    public BarColorMode barColorMode = BarColorMode.DURABILITY;       // цвет полоски
    public int barStartColor = 0xFFF35520;                            // свой цвет — начало
    public int barEndColor = 0xFFE8D030;                              // свой цвет — конец
    public int lineSpacing = 20;                                      // расстояние между строками

    // ============ ВНЕШНИЙ ВИД ============
    public boolean showBackground = true;              // показывать фон под панелью
    public int backgroundColor = 0xFECC76;             // цвет фона (жёлтый)
    public int backgroundTransparency = 95;            // прозрачность фона, %
    public boolean showFrame = true;                   // показывать рамку
    public int frameThickness = 1;                     // толщина рамки
    public int frameColor = 0xF17532;                  // цвет рамки
    public int frameTransparency = 95;                 // прозрачность рамки, %

    // ============ ГАММА ============
    public boolean gammaEnabled = false;               // гамма включена?
    public int gammaTargetPercent = 250;              // цель, % (0..1500)
    public boolean gammaSmooth = true;                 // плавный переход
    public float gammaTransitionTime = 2.0f;           // время перехода, сек

    // ============ НОЧНОЕ ЗРЕНИЕ ============
    public boolean nightVisionEnabled = false;         // NV включено?
    public boolean nightVisionSmooth = true;           // плавный переход
    public float nightVisionTransitionTime = 2.0f;     // время перехода, сек

    // ============ ФИКСАЦИЯ РАЗРЕШЕНИЯ ============
    // Используется для пересчёта позиций при смене разрешения/разворачивании
    public int savedScreenWidth = 0;
    public int savedScreenHeight = 0;
}