package com.example.sparkhud.config;

import com.example.sparkhud.SparkHUDMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("sparkhud.json");

    public static SparkHUDConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                return GSON.fromJson(Files.readString(CONFIG_PATH), SparkHUDConfig.class);
            } catch (IOException e) {
                SparkHUDMod.LOGGER.error("Failed to load config", e);
            }
        }
        return new SparkHUDConfig();
    }

    public static void save(SparkHUDConfig config) {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(config));
        } catch (IOException e) {
            SparkHUDMod.LOGGER.error("Failed to save config", e);
        }
    }
}