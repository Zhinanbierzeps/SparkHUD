package com.example.sparkhud.client;

import com.example.sparkhud.SparkHUDMod;
import com.example.sparkhud.config.ConfigManager;
import com.example.sparkhud.config.SparkHUDConfig;
import net.minecraft.client.Minecraft;

/**
 * Управляет гаммой (0..250%) и «ночным зрением» (0..400% буст).
 * Уведомления над хотбаром привязаны к длительности плавного перехода:
 * текст виден всё время анимации + 1 сек фейда после неё.
 */
public class GammaNightVisionManager {
    private static float originalGamma = 1.0f;

    // ===== ГАММА =====
    private static float gammaCurrent = 1.0f;
    private static float gammaStart = 1.0f;
    private static float gammaTarget = 1.0f;
    private static float gammaProgress = 1.0f;
    private static float gammaTime = 2.0f;

    // ===== НОЧНОЕ ЗРЕНИЕ (буст к гамме) =====
    private static final float NV_MAX_BOOST = 4.0f;
    private static float nvCurrent = 0f;
    private static float nvStart = 0f;
    private static float nvTarget = 0f;
    private static float nvProgress = 1.0f;
    private static float nvTime = 2.0f;

    // ===== УВЕДОМЛЕНИЯ =====
    // Сколько тиков ещё показывать уведомление. Считается как длительность перехода + фейд.
    private static int gammaNotifyTicks = 0;
    private static int nvNotifyTicks = 0;
    private static final int NOTIFY_FADE = 20; // 1 сек плавного исчезновения в конце

    public static void init() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null) {
            originalGamma = mc.options.gamma().get().floatValue();
            gammaCurrent = originalGamma;
            gammaStart = originalGamma;
            gammaTarget = originalGamma;
            gammaProgress = 1.0f;
        }
    }

    public static void toggleGamma() {
        SparkHUDConfig cfg = SparkHUDMod.CONFIG;
        cfg.gammaEnabled = !cfg.gammaEnabled;
        ConfigManager.save(cfg);
        SparkHUDMod.LOGGER.info("Gamma: " + cfg.gammaEnabled);
    }

    public static void toggleNightVision() {
        SparkHUDConfig cfg = SparkHUDMod.CONFIG;
        cfg.nightVisionEnabled = !cfg.nightVisionEnabled;
        ConfigManager.save(cfg);
        SparkHUDMod.LOGGER.info("NightVision: " + cfg.nightVisionEnabled);
    }

    public static void changeGammaTarget(int deltaPercent) {
        SparkHUDConfig cfg = SparkHUDMod.CONFIG;
        int newValue = cfg.gammaTargetPercent + deltaPercent;
        newValue = Math.max(0, Math.min(250, newValue));
        cfg.gammaTargetPercent = newValue;
        ConfigManager.save(cfg);
        SparkHUDMod.LOGGER.info("Gamma target: " + newValue + "%");
    }

    public static int getGammaPercent() { return Math.round(gammaCurrent * 100f); }
    public static int getNvPercent() { return Math.round((nvCurrent / NV_MAX_BOOST) * 100f); }
    public static float getGammaCurrent() { return gammaCurrent; }
    public static float getNvCurrent() { return nvCurrent; }
    public static boolean showGammaNotification() { return gammaNotifyTicks > 0; }
    public static boolean showNvNotification() { return nvNotifyTicks > 0; }

    public static float getGammaAlpha() {
        if (gammaNotifyTicks <= 0) return 0f;
        if (gammaNotifyTicks > NOTIFY_FADE) return 1f;
        return gammaNotifyTicks / (float) NOTIFY_FADE;
    }

    public static float getNvAlpha() {
        if (nvNotifyTicks <= 0) return 0f;
        if (nvNotifyTicks > NOTIFY_FADE) return 1f;
        return nvNotifyTicks / (float) NOTIFY_FADE;
    }

    public static void tick(Minecraft mc) {
        if (mc.options == null) return;
        SparkHUDConfig cfg = SparkHUDMod.CONFIG;

        // ===== ГАММА =====
        float desiredGamma = cfg.gammaEnabled ? cfg.gammaTargetPercent / 100f : originalGamma;
        desiredGamma = Math.max(0f, Math.min(2.5f, desiredGamma)); // 250%

        if (Math.abs(gammaTarget - desiredGamma) > 0.001f) {
            gammaStart = gammaCurrent;
            gammaTarget = desiredGamma;
            gammaProgress = 0f;
            gammaTime = cfg.gammaSmooth ? Math.max(0.1f, cfg.gammaTransitionTime) : 0.01f;
            // Уведомление показываем ровно длительность перехода + 1 сек фейда
            gammaNotifyTicks = (int)(gammaTime * 20) + NOTIFY_FADE;
        }
        if (gammaProgress < 1f) {
            if (gammaTime <= 0.01f) {
                gammaCurrent = gammaTarget;
                gammaProgress = 1f;
            } else {
                gammaProgress += 1f / (gammaTime * 20f);
                if (gammaProgress >= 1f) {
                    gammaProgress = 1f;
                    gammaCurrent = gammaTarget;
                } else {
                    gammaCurrent = gammaStart + (gammaTarget - gammaStart) * gammaProgress;
                }
            }
        }

        // ===== НОЧНОЕ ЗРЕНИЕ =====
        float desiredNv = cfg.nightVisionEnabled ? NV_MAX_BOOST : 0f;
        if (Math.abs(nvTarget - desiredNv) > 0.001f) {
            nvStart = nvCurrent;
            nvTarget = desiredNv;
            nvProgress = 0f;
            nvTime = cfg.nightVisionSmooth ? Math.max(0.1f, cfg.nightVisionTransitionTime) : 0.01f;
            nvNotifyTicks = (int)(nvTime * 20) + NOTIFY_FADE;
        }
        if (nvProgress < 1f) {
            if (nvTime <= 0.01f) {
                nvCurrent = nvTarget;
                nvProgress = 1f;
            } else {
                nvProgress += 1f / (nvTime * 20f);
                if (nvProgress >= 1f) {
                    nvProgress = 1f;
                    nvCurrent = nvTarget;
                } else {
                    nvCurrent = nvStart + (nvTarget - nvStart) * nvProgress;
                }
            }
        }

        if (gammaNotifyTicks > 0) gammaNotifyTicks--;
        if (nvNotifyTicks > 0) nvNotifyTicks--;
    }
}