package com.example.sparkhud.utils;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Font;

public class GradientUtils {
    public static void drawGradientText(GuiGraphicsExtractor graphics, Font font, String text, int x, int y, int startColor, int endColor) {
        if ((startColor & 0xFF000000) == 0) startColor |= 0xFF000000;
        if ((endColor & 0xFF000000) == 0) endColor |= 0xFF000000;

        int length = text.length();
        if (length == 0) return;

        int currentX = x;
        for (int i = 0; i < length; i++) {
            String ch = String.valueOf(text.charAt(i));
            float ratio = (float) i / (float) Math.max(1, length - 1);
            int color = interpolateColor(startColor, endColor, ratio);
            graphics.text(font, ch, currentX, y, color, true);
            currentX += font.width(ch);
        }
    }

    public static int interpolateColor(int color1, int color2, float ratio) {
        int a1 = (color1 >> 24) & 0xFF, a2 = (color2 >> 24) & 0xFF;
        int r1 = (color1 >> 16) & 0xFF, r2 = (color2 >> 16) & 0xFF;
        int g1 = (color1 >> 8) & 0xFF, g2 = (color2 >> 8) & 0xFF;
        int b1 = color1 & 0xFF, b2 = color2 & 0xFF;

        int a = (int) (a1 + (a2 - a1) * ratio);
        int r = (int) (r1 + (r2 - r1) * ratio);
        int g = (int) (g1 + (g2 - g1) * ratio);
        int b = (int) (b1 + (b2 - b1) * ratio);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}