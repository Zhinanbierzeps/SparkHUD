package com.example.sparkhud.mixin;

import com.example.sparkhud.SparkHUDMod;
import com.example.sparkhud.client.GammaNightVisionManager;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Миксин на LightmapRenderStateExtractor (26.3) — перехватывает Math.max(0, gamma),
 * который является валидатором, и подставляет значение гаммы из мода (0..1500%).
 * Используется стандартный @Redirect, чтобы не требовать MixinExtras.
 */
@Mixin(LightmapRenderStateExtractor.class)
public abstract class GammaMixin {

    @Redirect(
        method = "extract",
        at = @At(
            value = "INVOKE",
            target = "Ljava/lang/Math;max(FF)F",
            ordinal = 0
        )
    )
    private float sparkhud$overrideGamma(float a, float b) {
        if (SparkHUDMod.CONFIG == null) {
            return Math.max(a, b);
        }

        // Текущая гамма (плавно интерполируется в GammaNightVisionManager)
        float gamma = GammaNightVisionManager.getGammaCurrent();
        // Буст от ночного зрения (тоже плавно интерполируется)
        float nv = GammaNightVisionManager.getNvCurrent();

        // Суммарный эффект, кап 15.0 (1500%)
        return Math.min(15.0f, gamma + nv);
    }
}