package com.example.sparkhud;

import com.example.sparkhud.client.GammaNightVisionManager;
import com.example.sparkhud.config.SparkHUDConfig;
import com.example.sparkhud.config.ConfigManager;
import com.example.sparkhud.hud.HudRenderer;
import com.example.sparkhud.integration.ModMenuIntegration;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SparkHUDMod implements ClientModInitializer {
    public static final String MOD_ID = "sparkhud";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static SparkHUDConfig CONFIG;
    public static KeyMapping openConfigKey;
    public static KeyMapping gammaKey;
    public static KeyMapping nightVisionKey;
    public static KeyMapping gammaIncreaseKey;
    public static KeyMapping gammaDecreaseKey;

    @Override
    public void onInitializeClient() {
        CONFIG = ConfigManager.load();

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "info_hud"),
                HudRenderer::render
        );

        KeyMapping.Category CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        openConfigKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sparkhud.open_config",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_COMMA,
                CATEGORY
        ));

        gammaKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sparkhud.toggle_gamma",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_G,
                CATEGORY
        ));

        nightVisionKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sparkhud.toggle_night_vision",
                InputConstants.Type.KEYBOARD,
                InputConstants.KEY_H,
                CATEGORY
        ));

        // Новые клавиши — по умолчанию НЕ ПРИВЯЗАНЫ.
        // В 26.3 InputConstants.UNKNOWN — это Key, поэтому берём его значение через getValue().
        gammaIncreaseKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sparkhud.gamma_increase",
                InputConstants.Type.KEYBOARD,
                InputConstants.UNKNOWN.getValue(),
                CATEGORY
        ));
        gammaDecreaseKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sparkhud.gamma_decrease",
                InputConstants.Type.KEYBOARD,
                InputConstants.UNKNOWN.getValue(),
                CATEGORY
        ));

        GammaNightVisionManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.consumeClick()) {
                if (client.gui.screen() == null) {
                    client.gui.setScreen(ModMenuIntegration.createConfigScreen(null));
                }
            }
            while (gammaKey.consumeClick()) {
                GammaNightVisionManager.toggleGamma();
            }
            while (nightVisionKey.consumeClick()) {
                GammaNightVisionManager.toggleNightVision();
            }
            // Изменение целевой гаммы на ±10%
            while (gammaIncreaseKey.consumeClick()) {
                GammaNightVisionManager.changeGammaTarget(10);
            }
            while (gammaDecreaseKey.consumeClick()) {
                GammaNightVisionManager.changeGammaTarget(-10);
            }
            GammaNightVisionManager.tick(client);
        });

        LOGGER.info("SparkHUD 1.3 initialized.");
    }
}